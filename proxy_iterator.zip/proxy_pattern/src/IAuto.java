public interface IAuto {

    void beindit(Szemely szemely);
    void vezet (Szemely szemely);
}
