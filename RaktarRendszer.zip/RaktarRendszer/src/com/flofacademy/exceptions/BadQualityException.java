package com.flofacademy.exceptions;

public class BadQualityException extends Exception {

    public BadQualityException(String s) {
        super(s);
    }
}
